export const GEMINI_API_KEY = "AIzaSyAOBBjRelTU9FTb1QZXxAKpOHVzqkIKpNs";
